Acquired together from the relay workstation before shutdown. Keep the database and its sidecar together. Work on a copy. The accepted receipt is named in the maintenance chat.
