These are fictional email evidence files, not messages to send. Compare gateway disposition and Message-ID, then inspect the MIME attachment. Sender display names alone do not authenticate email.
