Compare the original survey with its resized feed preview. Survey annotations used Base64 for the old export system. No real location data is present.
